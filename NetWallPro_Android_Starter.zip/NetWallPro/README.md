
# NetWall Pro

Premium Android per-app firewall starter project.

## What this version does

- Premium dark/cyan UI
- Dashboard
- App list
- Search
- Real installed-app discovery
- Real Wi-Fi/mobile data usage through NetworkStatsManager when Usage Access is granted
- Persistent per-app Wi-Fi/Mobile rules
- Android VpnService permission flow
- Actual per-app blocking using VpnService's allowed-application split-tunnel behavior

## Important networking limitation

This MVP uses VpnService to route only selected blocked packages into a local VPN interface and intentionally does not forward their packets. Therefore those selected packages lose network access, while other packages bypass the VPN.

This is a valid local blocking architecture, but it is not a full packet-forwarding VPN.

For advanced production features such as:

- true Wi-Fi-only vs mobile-only filtering while both transports are changing
- DNS/domain blocking
- connection logs with remote IP/domain
- byte-accurate live counters
- IPv6 packet handling
- TCP/UDP forwarding
- QUIC handling
- background rule reconfiguration
- always-on/lockdown
- scheduled firewall rules

add a complete packet engine/tun2socks/native networking layer and thoroughly test OEM-specific Android behavior.

## Build

Open this folder in Android Studio with JDK 17.

Install Android SDK 37 if available.

Sync Gradle and run on a physical Android device.

## First run

1. Start the firewall.
2. Accept Android's VPN consent dialog.
3. Open Apps.
4. Toggle Wi-Fi or Mobile to Blocked.
5. Start/refresh the firewall after changing rules.

For real per-app data statistics, open Usage Access when prompted.
