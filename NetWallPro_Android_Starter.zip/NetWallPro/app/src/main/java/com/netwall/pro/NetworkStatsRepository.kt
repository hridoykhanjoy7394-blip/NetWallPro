
package com.netwall.pro

import android.app.AppOpsManager
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.provider.Settings
import android.os.Process
import android.os.UserHandle

data class DataUsage(
    val wifiBytes: Long = 0L,
    val mobileBytes: Long = 0L
) {
    val totalBytes: Long get() = wifiBytes + mobileBytes
}

class NetworkStatsRepository(private val context: Context) {

    private val statsManager =
        context.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager

    fun hasUsageAccess(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (android.os.Build.VERSION.SDK_INT >= 29) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun usageSettingsIntent(): Intent =
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

    fun usageForUid(uid: Int, start: Long, end: Long): DataUsage {
        if (!hasUsageAccess()) return DataUsage()

        val wifi = query(ConnectivityManager.TYPE_WIFI, uid, start, end)
        val mobile = query(ConnectivityManager.TYPE_MOBILE, uid, start, end)

        return DataUsage(wifiBytes = wifi, mobileBytes = mobile)
    }

    fun deviceUsage(start: Long, end: Long): DataUsage {
        if (!hasUsageAccess()) return DataUsage()

        return DataUsage(
            wifiBytes = queryDevice(ConnectivityManager.TYPE_WIFI, start, end),
            mobileBytes = queryDevice(ConnectivityManager.TYPE_MOBILE, start, end)
        )
    }

    private fun query(
        networkType: Int,
        uid: Int,
        start: Long,
        end: Long
    ): Long {
        return try {
            val stats = statsManager.queryDetailsForUid(
                networkType,
                null,
                start,
                end,
                uid
            )

            var total = 0L
            val bucket = android.app.usage.NetworkStats.Bucket()

            while (stats.hasNextBucket()) {
                stats.getNextBucket(bucket)
                total += bucket.rxBytes + bucket.txBytes
            }

            stats.close()
            total
        } catch (_: SecurityException) {
            0L
        } catch (_: Exception) {
            0L
        }
    }

    private fun queryDevice(
        networkType: Int,
        start: Long,
        end: Long
    ): Long {
        return try {
            val bucket = statsManager.querySummaryForDevice(
                networkType,
                null,
                start,
                end
            )
            bucket.rxBytes + bucket.txBytes
        } catch (_: SecurityException) {
            0L
        } catch (_: Exception) {
            0L
        }
    }
}
