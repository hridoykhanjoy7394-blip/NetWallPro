
package com.netwall.pro

import android.content.Context

data class Rule(
    val wifi: Boolean = false,
    val mobile: Boolean = false
)

class FirewallStore(context: Context) {
    private val prefs = context.getSharedPreferences("firewall_rules", Context.MODE_PRIVATE)

    fun getRule(packageName: String): Rule = Rule(
        wifi = prefs.getBoolean("${packageName}_wifi", false),
        mobile = prefs.getBoolean("${packageName}_mobile", false)
    )

    fun setRule(packageName: String, rule: Rule) {
        prefs.edit()
            .putBoolean("${packageName}_wifi", rule.wifi)
            .putBoolean("${packageName}_mobile", rule.mobile)
            .apply()
    }

    fun blockedPackages(): Set<String> {
        return prefs.all.keys
            .map { it.substringBeforeLast("_") }
            .filter { getRule(it).wifi || getRule(it).mobile }
            .toSet()
    }
}
