
package com.netwall.pro

import android.app.AppOpsManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF07111F)
private val Header = Color(0xFF111E32)
private val Card = Color(0xFF17263D)
private val Card2 = Color(0xFF203451)
private val Cyan = Color(0xFF20C6F4)
private val Blue = Color(0xFF2D6BEA)
private val Green = Color(0xFF20D39A)
private val Orange = Color(0xFFFF7925)
private val Red = Color(0xFFFF5364)
private val Muted = Color(0xFFA9B7CB)

data class AppItem(
    val label: String,
    val packageName: String,
    val uid: Int,
    val icon: android.graphics.drawable.Drawable?,
    val usage: DataUsage,
    val rule: Rule
)

class MainActivity : ComponentActivity() {

    private lateinit var store: FirewallStore
    private lateinit var stats: NetworkStatsRepository

    private val vpnPermission =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) {
            if (it.resultCode == RESULT_OK) {
                startFirewallService()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        store = FirewallStore(this)
        stats = NetworkStatsRepository(this)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(
                arrayOf("android.permission.POST_NOTIFICATIONS"),
                100
            )
        }

        setContent {
            NetWallTheme {
                NetWallApp(
                    store = store,
                    stats = stats,
                    onStartFirewall = { ensureVpnPermissionAndStart() },
                    onStopFirewall = { stopFirewallService() }
                )
            }
        }
    }

    private fun ensureVpnPermissionAndStart() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnPermission.launch(intent)
        } else {
            startFirewallService()
        }
    }

    private fun startFirewallService() {
        val intent = Intent(this, FirewallVpnService::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopFirewallService() {
        stopService(Intent(this, FirewallVpnService::class.java))
    }
}

@Composable
fun NetWallTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan,
            secondary = Green,
            background = Bg,
            surface = Card,
            onSurface = Color.White,
            onBackground = Color.White
        ),
        content = content
    )
}

@Composable
fun NetWallApp(
    store: FirewallStore,
    stats: NetworkStatsRepository,
    onStartFirewall: () -> Unit,
    onStopFirewall: () -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    var firewall by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var total by remember { mutableStateOf(DataUsage()) }
    var usageAccess by remember { mutableStateOf(stats.hasUsageAccess()) }

    fun reload() {
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                val pm = context.packageManager
                val begin = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY, 0)
                    set(java.util.Calendar.MINUTE, 0)
                    set(java.util.Calendar.SECOND, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                }.timeInMillis
                val end = System.currentTimeMillis()

                val installed = pm.getInstalledApplications(
                    PackageManager.GET_META_DATA
                )
                    .filter { it.packageName != context.packageName }
                    .filter {
                        pm.getLaunchIntentForPackage(it.packageName) != null
                    }

                val list = installed.map {
                    val usage = stats.usageForUid(
                        it.uid,
                        begin,
                        end
                    )

                    AppItem(
                        label = pm.getApplicationLabel(it).toString(),
                        packageName = it.packageName,
                        uid = it.uid,
                        icon = try {
                            pm.getApplicationIcon(it.packageName)
                        } catch (_: Exception) {
                            null
                        },
                        usage = usage,
                        rule = store.getRule(it.packageName)
                    )
                }.sortedByDescending { it.usage.totalBytes }

                list to stats.deviceUsage(begin, end)
            }

            apps = result.first
            total = result.second
            usageAccess = stats.hasUsageAccess()
        }
    }

    LaunchedEffect(refresh, usageAccess) {
        reload()
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF18344F)
            ) {
                NavButton(
                    "Dashboard",
                    Icons.Default.Shield,
                    tab == 0
                ) { tab = 0 }

                NavButton(
                    "Apps",
                    Icons.Default.Apps,
                    tab == 1
                ) { tab = 1 }

                NavButton(
                    "Data",
                    Icons.Default.DataUsage,
                    tab == 2
                ) { tab = 2 }

                NavButton(
                    "Logs",
                    Icons.Default.History,
                    tab == 3
                ) { tab = 3 }
            }
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Bg)
                .padding(padding)
        ) {

            TopHeader(
                onRefresh = { refresh++ }
            )

            when (tab) {

                0 -> Dashboard(
                    total = total,
                    blocked = apps.count {
                        it.rule.wifi || it.rule.mobile
                    },
                    firewall = firewall,
                    onFirewall = {
                        firewall = !firewall

                        if (firewall) {
                            onStartFirewall()
                        } else {
                            onStopFirewall()
                        }
                    },
                    onApps = { tab = 1 }
                )

                1 -> AppsScreen(
                    apps = apps,
                    usageAccess = usageAccess,
                    onUsageAccess = {
                        context.startActivity(
                            stats.usageSettingsIntent()
                        )
                    },
                    onRule = { app, wifi, mobile ->

                        store.setRule(
                            app.packageName,
                            Rule(wifi, mobile)
                        )

                        refresh++

                        if (firewall) {
                            onStartFirewall()
                        }
                    }
                )

                2 -> DataScreen(
                    total = total,
                    apps = apps
                )

                3 -> LogsScreen()
            }
        }
    }
}

@Composable
fun TopHeader(onRefresh: () -> Unit) {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Header)
            .padding(
                horizontal = 20.dp,
                vertical = 18.dp
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {

        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF173F70),
                            Color(0xFF071A32)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Security,
                contentDescription = null,
                tint = Cyan,
                modifier = Modifier.size(30.dp)
            )
        }

        Spacer(Modifier.width(12.dp))

        Column(
            modifier = Modifier.weight(1f)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "NetWall Pro",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.width(7.dp))

                Box(
                    Modifier
                        .size(9.dp)
                        .clip(CircleShape)
                        .background(Green)
                )
            }

            Text(
                "Private • Secure • Local",
                color = Muted,
                fontSize = 12.sp
            )
        }

        Surface(
            shape = RoundedCornerShape(25.dp),
            color = Color(0xFF087EA8)
        ) {
            Text(
                "EN",
                modifier = Modifier.padding(
                    horizontal = 16.dp,
                    vertical = 10.dp
                ),
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.width(8.dp))

        IconButton(onClick = onRefresh) {
            Icon(
                Icons.Default.Refresh,
                contentDescription = "Refresh",
                tint = Color.White
            )
        }
    }
}

@Composable
fun Dashboard(
    total: DataUsage,
    blocked: Int,
    firewall: Boolean,
    onFirewall: () -> Unit,
    onApps: () -> Unit
) {

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {

        item {
            FirewallCard(
                active = firewall,
                blocked = blocked,
                onToggle = onFirewall
            )
        }

        item {
            DataCard(total)
        }

        item {
            SectionTitle(
                "Top Data Consuming Apps",
                "Quickly manage Wi-Fi and mobile access"
            )
        }

        item {
            Button(
                onClick = onApps,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Card2
                ),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Default.Apps, null)
                Spacer(Modifier.width(8.dp))
                Text("Manage installed apps")
            }
        }
    }
}

@Composable
fun FirewallCard(
    active: Boolean,
    blocked: Int,
    onToggle: () -> Unit
) {

    Card(
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier.fillMaxWidth()
    ) {

        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF075080),
                            Color(0xFF086C9E)
                        )
                    )
                )
                .padding(24.dp)
        ) {

            Column {

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Box(
                        Modifier
                            .size(58.dp)
                            .clip(CircleShape)
                            .background(
                                Color.White.copy(alpha = .08f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Shield,
                            null,
                            tint = Green,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(Modifier.width(14.dp))

                    Column(
                        modifier = Modifier.weight(1f)
                    ) {

                        Text(
                            if (active)
                                "Firewall Active"
                            else
                                "Firewall Off",
                            fontSize = 27.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            if (active)
                                "Network traffic is guarded"
                            else
                                "Firewall is currently disabled",
                            color = Color.White.copy(.75f)
                        )
                    }

                    Switch(
                        checked = active,
                        onCheckedChange = { onToggle() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Green
                        )
                    )
                }

                Spacer(Modifier.height(22.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.Black.copy(.20f))
                        .padding(18.dp),
                    horizontalArrangement =
                        Arrangement.SpaceBetween
                ) {

                    Column {
                        Text(
                            "Active Network",
                            color = Muted
                        )
                        Text(
                            "System network",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            "Blocked Apps",
                            color = Muted
                        )
                        Text(
                            blocked.toString(),
                            color = Red,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DataCard(total: DataUsage) {

    Card(
        colors = CardDefaults.cardColors(
            containerColor = Card
        ),
        shape = RoundedCornerShape(28.dp)
    ) {

        Column(
            Modifier.padding(24.dp)
        ) {

            Text(
                "Today's Total Data Usage",
                color = Muted,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold
            )

            Text(
                formatBytes(total.totalBytes),
                color = Cyan,
                fontSize = 42.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Spacer(Modifier.height(18.dp))

            val all = total.totalBytes.coerceAtLeast(1)
            val wifiFraction =
                (total.wifiBytes.toFloat() / all)
                    .coerceIn(0f, 1f)

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(16.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF293D5C))
            ) {

                Row(Modifier.fillMaxSize()) {

                    Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(wifiFraction)
                            .background(Blue)
                    )

                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(Orange)
                    )
                }
            }

            Spacer(Modifier.height(18.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement =
                    Arrangement.spacedBy(12.dp)
            ) {

                DataMini(
                    "Wi-Fi",
                    formatBytes(total.wifiBytes),
                    Blue,
                    Modifier.weight(1f)
                )

                DataMini(
                    "Mobile",
                    formatBytes(total.mobileBytes),
                    Orange,
                    Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun DataMini(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier
) {

    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Card2)
            .padding(16.dp)
    ) {

        Text(
            "● $title",
            color = color,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(7.dp))

        Text(
            value,
            fontSize = 21.sp,
            fontWeight = FontWeight.ExtraBold
        )
    }
}

@Composable
fun AppsScreen(
    apps: List<AppItem>,
    usageAccess: Boolean,
    onUsageAccess: () -> Unit,
    onRule: (AppItem, Boolean, Boolean) -> Unit
) {

    var query by remember { mutableStateOf("") }

    val filtered = remember(apps, query) {
        apps.filter {
            it.label.contains(query, true) ||
                    it.packageName.contains(query, true)
        }
    }

    Column(
        Modifier.fillMaxSize()
    ) {

        if (!usageAccess) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF3D3020)
                ),
                shape = RoundedCornerShape(20.dp)
            ) {

                Row(
                    Modifier.padding(16.dp),
                    verticalAlignment =
                        Alignment.CenterVertically
                ) {

                    Icon(
                        Icons.Default.Info,
                        null,
                        tint = Orange
                    )

                    Spacer(Modifier.width(12.dp))

                    Column(
                        Modifier.weight(1f)
                    ) {
                        Text(
                            "Usage access required",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Allow access to show real per-app data usage.",
                            color = Muted,
                            fontSize = 12.sp
                        )
                    }

                    TextButton(
                        onClick = onUsageAccess
                    ) {
                        Text("OPEN")
                    }
                }
            }
        }

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp),
            placeholder = {
                Text("Search app or package name")
            },
            leadingIcon = {
                Icon(Icons.Default.Search, null)
            },
            singleLine = true,
            shape = RoundedCornerShape(18.dp)
        )

        Text(
            "${filtered.size} apps",
            modifier = Modifier.padding(
                start = 20.dp,
                top = 18.dp,
                bottom = 8.dp
            ),
            color = Muted
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = 18.dp,
                end = 18.dp,
                bottom = 25.dp
            ),
            verticalArrangement =
                Arrangement.spacedBy(12.dp)
        ) {

            items(
                filtered,
                key = { it.packageName }
            ) { app ->

                AppRow(
                    app = app,
                    onRule = onRule
                )
            }
        }
    }
}

@Composable
fun AppRow(
    app: AppItem,
    onRule: (AppItem, Boolean, Boolean) -> Unit
) {

    Card(
        colors = CardDefaults.cardColors(
            containerColor = Card
        ),
        shape = RoundedCornerShape(22.dp)
    ) {

        Column(
            Modifier.padding(15.dp)
        ) {

            Row(
                verticalAlignment =
                    Alignment.CenterVertically
            ) {

                if (app.icon != null) {
                    androidx.compose.ui.viewinterop.AndroidView(
                        factory = { context ->
                            android.widget.ImageView(context)
                        },
                        update = {
                            it.setImageDrawable(app.icon)
                        },
                        modifier = Modifier.size(54.dp)
                    )
                } else {
                    Box(
                        Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(15.dp))
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Apps,
                            null,
                            tint = Color.Black
                        )
                    }
                }

                Spacer(Modifier.width(13.dp))

                Column(
                    Modifier.weight(1f)
                ) {

                    Text(
                        app.label,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        app.packageName,
                        color = Color(0xFF7F8DA4),
                        fontSize = 11.sp,
                        maxLines = 1
                    )

                    Text(
                        formatBytes(app.usage.totalBytes),
                        color = Cyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(
                horizontalArrangement =
                    Arrangement.spacedBy(10.dp)
            ) {

                RuleButton(
                    label = "Wi-Fi",
                    icon = Icons.Default.Wifi,
                    checked = app.rule.wifi,
                    color = Blue
                ) {
                    onRule(
                        app,
                        !app.rule.wifi,
                        app.rule.mobile
                    )
                }

                RuleButton(
                    label = "Mobile",
                    icon = Icons.Default.SignalCellularAlt,
                    checked = app.rule.mobile,
                    color = Orange
                ) {
                    onRule(
                        app,
                        app.rule.wifi,
                        !app.rule.mobile
                    )
                }
            }
        }
    }
}

@Composable
fun RuleButton(
    label: String,
    icon: ImageVector,
    checked: Boolean,
    color: Color,
    onClick: () -> Unit
) {

    val background by animateColorAsState(
        if (checked)
            color.copy(alpha = .22f)
        else
            Color(0xFF21334F),
        label = "ruleBg"
    )

    Surface(
        modifier = Modifier
            .weight(1f)
            .clickable { onClick() },
        color = background,
        shape = RoundedCornerShape(14.dp)
    ) {

        Row(
            Modifier.padding(11.dp),
            verticalAlignment =
                Alignment.CenterVertically,
            horizontalArrangement =
                Arrangement.Center
        ) {

            Icon(
                icon,
                null,
                tint = color
            )

            Spacer(Modifier.width(7.dp))

            Text(
                if (checked) "Blocked" else "Allowed",
                fontWeight = FontWeight.Bold,
                color = if (checked) color else Color.White
            )
        }
    }
}

@Composable
fun DataScreen(
    total: DataUsage,
    apps: List<AppItem>
) {

    LazyColumn(
        contentPadding = PaddingValues(18.dp),
        verticalArrangement =
            Arrangement.spacedBy(15.dp)
    ) {

        item {
            DataCard(total)
        }

        item {
            SectionTitle(
                "App-Wise Data Consumption",
                "Sorted by today's total usage"
            )
        }

        items(apps.take(20)) { app ->

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Card
                ),
                shape = RoundedCornerShape(20.dp)
            ) {

                Row(
                    Modifier.padding(16.dp),
                    verticalAlignment =
                        Alignment.CenterVertically
                ) {

                    Text(
                        app.label,
                        Modifier.weight(1f),
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        formatBytes(app.usage.totalBytes),
                        color = Cyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun LogsScreen() {

    val logs = listOf(
        "Firewall service started",
        "Rules loaded successfully",
        "Network protection enabled",
        "Local VPN interface established"
    )

    LazyColumn(
        contentPadding = PaddingValues(18.dp),
        verticalArrangement =
            Arrangement.spacedBy(12.dp)
    ) {

        item {
            SectionTitle(
                "Firewall Logs",
                "Recent local events"
            )
        }

        items(logs) { log ->

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Card
                ),
                shape = RoundedCornerShape(18.dp)
            ) {

                Row(
                    Modifier.padding(18.dp),
                    verticalAlignment =
                        Alignment.CenterVertically
                ) {

                    Icon(
                        Icons.Default.Shield,
                        null,
                        tint = Green
                    )

                    Spacer(Modifier.width(12.dp))

                    Text(log)
                }
            }
        }
    }
}

@Composable
fun SectionTitle(
    title: String,
    subtitle: String
) {

    Column {

        Text(
            title,
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold
        )

        Text(
            subtitle,
            color = Muted,
            fontSize = 14.sp
        )
    }
}

@Composable
fun RowScope.NavButton(
    title: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {

    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = {
            Icon(icon, contentDescription = title)
        },
        label = {
            Text(title)
        },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Color.White,
            selectedTextColor = Color.White,
            indicatorColor = Color(0xFF65576F),
            unselectedIconColor = Muted,
            unselectedTextColor = Muted
        )
    )
}

fun formatBytes(bytes: Long): String {

    if (bytes <= 0) return "0 B"

    val kb = 1024.0
    val mb = kb * 1024
    val gb = mb * 1024

    return when {
        bytes >= gb ->
            String.format("%.1f GB", bytes / gb)

        bytes >= mb ->
            String.format("%.1f MB", bytes / mb)

        bytes >= kb ->
            String.format("%.1f KB", bytes / kb)

        else ->
            "$bytes B"
    }
}
