
package com.netwall.pro

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat

class FirewallVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundNotification()
        establishBlockVpn()
        return START_STICKY
    }

    private fun establishBlockVpn() {
        vpnInterface?.close()
        vpnInterface = null

        val store = FirewallStore(this)
        val blocked = store.blockedPackages()
            .filter { it != packageName }

        if (blocked.isEmpty()) {
            stopSelf()
            return
        }

        val builder = Builder()
            .setSession("NetWall Pro")
            .setMtu(1500)
            .setBlocking(false)
            .addAddress("10.10.0.2", 32)
            .addRoute("0.0.0.0", 0)

        /*
         * Important:
         * addAllowedApplication() means ONLY these packages use this VPN.
         * Because this MVP does not forward packets, those selected packages
         * effectively lose network access, while all other apps bypass it.
         *
         * Android documents this split-tunnel behavior:
         * https://developer.android.com/reference/android/net/VpnService.Builder
         */
        blocked.forEach { pkg ->
            try {
                builder.addAllowedApplication(pkg)
            } catch (_: Exception) {
                // Package may have been uninstalled.
            }
        }

        vpnInterface = builder.establish()

        if (vpnInterface == null) {
            stopSelf()
        }
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    private fun stopVpn() {
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }
        vpnInterface = null
    }

    private fun startForegroundNotification() {
        val channelId = "firewall"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Firewall",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("NetWall Pro")
            .setContentText("Firewall is protecting your device")
            .setSmallIcon(android.R.drawable.ic_secure)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        startForeground(1001, notification)
    }

    companion object {
        const val ACTION_START = "com.netwall.pro.START"
        const val ACTION_STOP = "com.netwall.pro.STOP"
    }
}
